jQuery( document ).ready(function() {
    
    //alert( "ready!" );
    
});

//dot_set_token_fee_global
jQuery('#dot_save_gmaps_key').on('click',function(event){
    event.preventDefault();
    jQuery( '#dot_gmaps_key_status' ).html( 'Dot is now saving google maps key.... (wait)' );
    
    var dotww_gmaps_key = jQuery('#dotww_gmaps_key').val();

    if(!dotww_gmaps_key){
        jQuery( '#dot_gmaps_key_status' ).html( 'Error: Google Maps key is invalid or empty.' );
        return;
    }else{
        var dataa = {
            dotww_gmaps_key: dotww_gmaps_key,
            action: 'dot_save_gmaps_key'
        };   
        jQuery.post( ajax_url, dataa, function(response) {  
            console.log(response);
            jQuery( '#dot_gmaps_key_status' ).html( response.message );
        });
    }
    
});


//dot_set_token_fee_global
jQuery('#dot_save_price_label').on('click',function(event){
    event.preventDefault();
    jQuery( '#dot_label_status' ).html( 'Dot is now saving price label.... (wait)' );
    
    var dotww_price_label = jQuery('#dotww_price_label').val();

    if(!dotww_price_label){
        jQuery( '#dot_label_status' ).html( 'Error: Either Token Value or Token fee is empty.' );
        return;
    }else{
        var dataa = {
            dotww_price_label: dotww_price_label,
            action: 'dot_save_price_label'
        };   
        jQuery.post( ajax_url, dataa, function(response) {  
            console.log(response);
            jQuery( '#dot_label_status' ).html( response.message );
        });
    }
    
});


//saving error message
jQuery('#dot_save_dotww_outofzone_error').on('click',function(event){
    event.preventDefault();
    jQuery( '#dot_oerror_status' ).html( 'Dot is now saving OUROFZONE ERROR MESSAGE.... (wait)' );
    
    var dotww_outofzone_error = jQuery('#dotww_outofzone_error').val();

    if(!dotww_outofzone_error){
        jQuery( '#dot_oerror_status' ).html( 'Error: Out Of Zone Error Message is empty or contains invalid characters.' );
        return;
    }else{
        var dataa = {
            dotww_outofzone_error: dotww_outofzone_error,
            action: 'dot_save_outofzone_error'
        };   
        jQuery.post( ajax_url, dataa, function(response) {  
            console.log(response);
            jQuery( '#dot_oerror_status' ).html( response.message );
        });
    }
    
});

jQuery('#dot_save_condition').on('click',function(event){
    event.preventDefault();
    jQuery( '#dot_condition_status' ).html( 'Dot is now saving new condition.... (wait)' );
    
    var dotww_distance = jQuery('#dotww_distance').val();
    var dotww_price = jQuery('#dotww_price').val();

    if(!dotww_distance || !dotww_price){
        jQuery( '#dot_condition_status' ).html( 'Error: Either Token Value or Token fee is empty.' );
        return;
    }else{
        var dataa = {
            dotww_distance: dotww_distance,
            dotww_price: dotww_price,
            action: 'dot_save_condition'
        };   
        jQuery.post( ajax_url, dataa, function(response) {  
            console.log(response);
            jQuery( '#dot_condition_status' ).html( response.message );
            location.reload();
        });
    }
    
});

jQuery('.dot_delete_condition').on('click',function(event){
    event.preventDefault();
    var dot_condition_id= jQuery(this).data('condition_id');
    
    
    if(dot_condition_id === null){
        jQuery( '.dot_status_'+dot_condition_id ).html( 'Ivalid Request.' );
        return;
    }else{
        jQuery( '.dot_status_'+dot_condition_id ).html( 'Deleting Condition. Wait!' );
        var dataa = {
            dot_condition_id: dot_condition_id,
            action: 'dot_delete_condition'
        };
        
        jQuery.post( ajax_url, dataa, function(response) {  
            console.log(response);
            jQuery( '.dot_status_'+dot_condition_id ).html( 'Condition Deleted!' );
            location.reload();
        });
    }
    

    
});
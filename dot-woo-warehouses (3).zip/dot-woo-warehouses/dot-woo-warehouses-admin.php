<?php  
$dotww_options = get_option('dotww_options');
if($dotww_options){
    $dotww_options = json_decode($dotww_options, true);
}else{
    $dotww_options = array();
}

$dotww_price_label = get_option('dotww_price_label') ? get_option('dotww_price_label'):'';
$dotww_gmaps_key = get_option('dotww_gmaps_key') ? get_option('dotww_gmaps_key'):'';
$dotww_outofzone = get_option('dotww_outofzone_error') ? get_option('dotww_outofzone_error'):'';
            
?>
<script type="text/javascript">
    var ajax_url = "<?php echo admin_url('admin-ajax.php'); ?>";
</script>


<h2>Custom Distance Based Additional Prices</h2>
<p>Create Conditions to add additional prices to checkour.</p>

<hr>

<h3>Set Label for Additional Fee (Global)</h3>
<p>Label that will show with additional price in checkout panel.</p>
<input type="text" id="dotww_price_label" class="dotww_price_label" name="dotww_price_label" value="<?php echo $dotww_price_label; ?>">
<br><br>

<button id="dot_save_price_label">Save Label</button>
<p id="dot_label_status"></p>

<hr>

<h3>Set Out of Zone Error Message (Global)</h3>
<p>Error that will show when distance will be out of zone.</p>
<input type="text" id="dotww_outofzone_error" class="dotww_outofzone_error" name="dotww_outofzone_error" value="<?php echo $dotww_outofzone; ?>">
<br><br>

<button id="dot_save_dotww_outofzone_error">Save Out of Zone Error Message</button>
<p id="dot_oerror_status"></p>

<hr>
<h3>Your Google Maps API key</h3>
<p>This will be used to check if customer is within a specific radius (km)</p>
<input type="text" id="dotww_gmaps_key" class="dotww_gmaps_key" name="dotww_pricedotww_gmaps_key_label" value="<?php echo $dotww_gmaps_key; ?>">
<br><br>

<button id="dot_save_gmaps_key">Save key</button>
<p id="dot_gmaps_key_status"></p>

<hr>
<h3>Conditions</h3>
<p>Configure condition according to distance.</p>
<p>Conditions should be in sequence. (smaller distance to larger distance). The last condition will be considered as limit. If distance is greater than the last condition. Error 'Out of Zone' will show up during checkout.</P>
<p>If Customer is within
<input type="number" id="dotww_distance" class="dotww_distance" name="dotww_distance" value="10">kms radius, then Add 
<input type="number" id="dotww_price" class="dotww_price" name="dotww_price" value="10">€ to total checkout. 
</p>
<button id="dot_save_condition">Save Condition</button>
<p id="dot_condition_status"></p>
<hr>

<br>
<br>
<h2>Active Conditions</h2>
<table class="wp-list-table widefat fixed striped table-view-list ">
    <thead>
    	<th>Condition</th>
    	<th>Price to be Added</th>
    	<th>Actions</th>
    </thead>
    <tbody>
        <?php
        foreach($dotww_options as $key=>$condition){
            if($key == 0){
                $key = 'f';
            }
        ?>
            <tr>
                <td>Customer within <strong><?php echo $condition['dotww_distance'] ?>km</strong> Radius</td>
                <td>Add <strong><?php echo $condition['dotww_price'] ?>€</strong></td>
                <td>
                    <button class="dot_delete_condition" data-condition_id="<?php echo $key; ?>">Delete Condition</button>
                    <p class="dot_status_<?php echo $key; ?>"></p>
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>
<?php if ( ! defined( 'ABSPATH' ) ){ exit; }else{ clearstatcache(); }
/**
 * Plugin Name:       		Dot Woo Warehouses
 * Description:       		This plugin will help you manage WooCommerce Products stocks throw locations.
 * Version:					1.0.0
 * Requires at least: 		4.9
 * Requires PHP:      		7.2
 * Author:            		Muhammad Ahmad & Machination Tech
 * Author URI:        		https://machination.tech
 * License:           		GPL v2 or later
 * License URI:       		https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       		dot-woo-warehouses
 * Domain Path:       		/languages
 * WC requires at least:	3.4
 * WC tested up to: 		5.3
 */

/**
 * If this file is called directly, abort.
 *
 * @since 1.0.0
 */
if ( !defined( 'WPINC' ) ) {
	die;
}

global $dotww_plugin_settings;
$dotww_plugin_settings = get_option( 'slw_settings' );
$dotw_plugin_settings = is_array($dotww_plugin_settings)?$dotww_plugin_settings:array();

/**
 * Register a dotww prince settings page.
 */
add_action( 'admin_menu', 'dot_register_dot_st_menu_page' );
function dot_register_dot_st_menu_page() {
    add_menu_page(
        __( 'Distance Prices', 'dot-woo-warehouses' ), //page title
        'Distance Prices', //menu title
        'manage_options', //capability
        'dot-woo-warehouses/dot-woo-warehouses-admin.php', //menu slug
        '', //callback function (render function)
        'dashicons-xing',
        40 //position
    );
}

//adding javascript and style to dot-st menu page
add_action( 'admin_enqueue_scripts', 'dot_add_scripts_to_dot_st_menu_page' );
function dot_add_scripts_to_dot_st_menu_page()
{
    global $pagenow;
    
    if ($pagenow != 'admin.php') {
        return;
    }
    // loading css
    //wp_register_style( 'dot-st-css', plugins_url( 'css/dot_style.css' , __FILE__ ), false, '1.0.0' );
    //wp_enqueue_style( 'dot-st-css' );
     
    // loading js
    wp_register_script( 'dot-st-js', plugins_url( 'js/dot_script.js' , __FILE__ ), array('jquery-core'), false, true );
    wp_enqueue_script( 'dot-st-js' );
}


/**
 * Activate the plugin.
 */
function dotww_activate() { 
    // Trigger our function that registers the warehouses taxonomy for products.
    dotww_create_warehouses_taxonomy();
    flush_rewrite_rules(); 
}
register_activation_hook( __FILE__, 'dotww_activate' );



/**
 * Register the "book" custom post type
 */

function dotww_create_warehouses_taxonomy()  {
    $labels = array(
        'name'                       => 'Warehouses',
        'singular_name'              => 'Warehouse',
        'menu_name'                  => 'Warehouses',
        'all_items'                  => 'All Warehouses',
        'parent_item'                => 'Parent Warehouse',
        'parent_item_colon'          => 'Parent Warehouse:',
        'new_item_name'              => 'New Warehouse Name',
        'add_new_item'               => 'Add New Warehouse',
        'edit_item'                  => 'Edit Warehouse',
        'update_item'                => 'Update Warehouse',
        'separate_items_with_commas' => 'Separate Warehouses with commas',
        'search_items'               => 'Search Warehouses',
        'add_or_remove_items'        => 'Add or remove Warehouses',
        'choose_from_most_used'      => 'Choose from the most used Warehouses',
    );
    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => true,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => true,
        'show_in_nav_menus'          => true,
        'show_tagcloud'              => true,
    );
    register_taxonomy( 'warehouse', 'product', $args );  
}
add_action( 'init', 'dotww_create_warehouses_taxonomy', 0 );

/**
 * Adding additional fields to product taxonomy 
 */
function dot_edit_warehouse_fields( $term, $taxonomy ) {

	$dotww_city = get_term_meta( $term->term_id, 'dotww-city', true );
	$dotww_address = get_term_meta( $term->term_id, 'dotww-address', true );
	
	echo '<tr class="form-field">
	<th>
		<label for="dotww-address">Warehouse Address</label>
	</th>
	<td>
		<textarea name="dotww-address" id="dotww-address">' . esc_attr( $dotww_address ) .'</textarea>
		<p class="description">This address will be used to calculate distance between warehouse and customer shipping address during checkout.</p>
	</td>
	</tr>';

}
add_action( 'warehouse_edit_form_fields', 'dot_edit_warehouse_fields', 10, 2 );


/**
 * Saving additional fields to product taxonomy 
 */
function dotww_save_term_fields( $term_id ) {

	update_term_meta(
		$term_id,
		'dotww-address',
		sanitize_text_field( $_POST[ 'dotww-address' ] )
	);

}
add_action( 'created_warehouse', 'dotww_save_term_fields' );
add_action( 'edited_warehouse', 'dotww_save_term_fields' );





/**
 * adding additional cost to checkout based on city.
 */
function dot_add_additional_cost() {
    if (is_admin() && !defined('DOING_AJAX')) {
        //return;
    }
    
    $dotww_price_label = get_option('dotww_price_label') ? get_option('dotww_price_label'):'Additional Cost';
    $dotww_options = get_option('dotww_options');
    if($dotww_options){
        $dotww_options = json_decode($dotww_options, true);
    }else{
        $dotww_options = array();
    }
    
    foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
    	$quantity     = $cart_item['quantity']; 
    	$product_id   = $cart_item['product_id'];
    	$variation_id = $cart_item['variation_id'];

        $warehouses = wp_get_post_terms( $product_id, 'warehouse', array('fields' => 'names') );
        if ( count($warehouses) > 0 ) {
            $warehouses = $warehouses[0];
        }
	}


	//getting warehouse address of product
    $warehouse = get_term_by( 'slug', $warehouses, 'warehouse' );
    $warehouse_address = get_term_meta( $warehouse->term_id, 'dotww-address', true);
    
    
    //getting customer address
    global $woocommerce;
    
    $c_addr1 = $woocommerce->checkout->get_value( 'billing_address_1' );
    $c_addr2 = $woocommerce->checkout->get_value( 'billing_address_2' );
    $c_postcode = $woocommerce->checkout->get_value( 'billing_postcode' );
    $c_city = $woocommerce->checkout->get_value( 'billing_city' );
    $c_country = $woocommerce->checkout->get_value( 'billing_country' );
    
    $destination_address=$c_addr1." ".$c_addr2." ".$c_postcode." ".$c_city." ".$c_country;
    
    if(!empty($dotww_options)){
        $distance = dot_get_distance ($warehouse_address, $destination_address);
        if(!is_numeric($distance)){
             //wc_add_notice( __( $distance, 'woocommerce' ), 'error' );
             return;
        }
        $price_to_be_added = 0;
        $dds = array_column($dotww_options, 'dotww_price');
        array_multisort($dds, SORT_DESC, $dotww_options);
        
        foreach($dotww_options as $condition){
            if($distance <= $condition['dotww_distance']){
                $price_to_be_added = $condition['dotww_price'];   
            }
        }
        $cartTotal=WC()->cart->get_cart_contents_total();
        if($price_to_be_added > 0){
        	wc_clear_notices();
            WC()->cart->add_fee($dotww_price_label, $price_to_be_added);
        }else{
        	// Clear all other notices          
            wc_clear_notices();
            // Notice
            $dotww_outofzone = get_option('dotww_outofzone_error') ? get_option('dotww_outofzone_error'):'Out of Zone. We cannot deliver this product to the selected city.';
            wc_add_notice( __( $dotww_outofzone, 'woocommerce' ) );
        }
    }else{
        //WC()->cart->add_fee('conditions not found', 11);
    }
}
add_action('woocommerce_cart_calculate_fees', 'dot_add_additional_cost');


/**
 * adding a trigger to update checkout on city change.
 */
add_filter( 'woocommerce_checkout_fields' , 'trigger_update_checkout_on_change' );
function trigger_update_checkout_on_change( $fields ) {

    $fields['billing']['billing_city']['class'][] = 'update_totals_on_change';
    return $fields;
}

// ajax function that gets called to save additional price label 
add_action("wp_ajax_dot_save_gmaps_key", "dot_save_gmaps_key");

function dot_save_gmaps_key(){
	if ( isset( $_POST['dotww_gmaps_key'] ) ) {
    	$status = update_option('dotww_gmaps_key', $_POST['dotww_gmaps_key']);
        $return = array( 'message' => "Google Maps Key is saved." );
        wp_send_json( $return );
    }else{
    	$return = array( 'message' => "Error: Make sure Google Maps Key is valid!!!" );
        wp_send_json( $return );
    }
}

// ajax function that gets called to save additional price label 
add_action("wp_ajax_dot_save_price_label", "dot_save_price_label");

function dot_save_price_label(){
	if ( isset( $_POST['dotww_price_label'] ) ) {
    	$status = update_option('dotww_price_label', $_POST['dotww_price_label']);
        $return = array( 'message' => "Pricing Label is saved." );
        wp_send_json( $return );
    }else{
    	$return = array( 'message' => "Error: Make sure Pricing Label is valid!!!" );
        wp_send_json( $return );
    }
}

// ajax function that gets called to save additional price label 
add_action("wp_ajax_dot_save_outofzone_error", "dot_save_outofzone_error");

function dot_save_outofzone_error(){
	if ( isset( $_POST['dotww_outofzone_error'] ) ) {
    	$status = update_option('dotww_outofzone_error', $_POST['dotww_outofzone_error']);
        $return = array( 'message' => "OUTOFZONE-Error-Message is saved." );
        wp_send_json( $return );
    }else{
    	$return = array( 'message' => "Error: Make sure Error Message is valid!!!" );
        wp_send_json( $return );
    }
}

// ajax function that gets called to create new conditions
add_action("wp_ajax_dot_save_condition", "dot_save_condition");

function dot_save_condition() {
    if ( isset( $_POST['dotww_distance'] ) &&  isset( $_POST['dotww_price'] ) ) {
        $dotww_distance  = $_POST['dotww_distance'];
        $dotww_price  = $_POST['dotww_price'];
        
        if ( !empty( $dotww_distance ) && !empty( $dotww_price ) ) {
            
            //creating dot-st-code
            $dotww_options = get_option('dotww_options');
            if($dotww_options){
                $dotww_options = json_decode($dotww_options, true);
            }else{
            	$dotww_options = array();
            }
            $dotww_options[]=array('dotww_distance'=>$dotww_distance, 'dotww_price'=>$dotww_price);
            $status = update_option('dotww_options', json_encode($dotww_options));
        }
        $return = array( 'message' => "New Condition is saved." );
        wp_send_json( $return );
    }else{
        $return = array( 'message' => "Error: Make sure all field are filled correctly!!!" );
        wp_send_json( $return );
    }
    
}

// ajax function that gets called to delete conditions
add_action("wp_ajax_dot_delete_condition", "dot_delete_condition");

function dot_delete_condition() {
    if ( isset( $_POST['dot_condition_id'] ) ) {
        $dot_condition_id  = $_POST['dot_condition_id'];
        
        
        if ( !empty( $dot_condition_id ) ) {
            $dotww_options = get_option('dotww_options');
            if($dotww_options){
                $dotww_options = json_decode($dotww_options, true);
            }
            if($dot_condition_id == 'f'){
                unset($dotww_options[0]);
            }else{
                unset($dotww_options[$dot_condition_id]);
            }
            
            $status = update_option('dotww_options', json_encode($dotww_options));
        }
        $return = array( 'message' => "Condition Deleted." );
        wp_send_json( $return );
    }else{
        $return = array( 'message' => "Error: Contact Support!!!" );
        wp_send_json( $return );
    }
    
}

//function to get distance between 2 addresses
//$src = "Champ de Mars, 5 Av. Anatole France, 75007 Paris, France";
//$dest = "35 Rue du Chevalier de la Barre";
//dot_get_distance($src,$dest);

function dot_get_distance($addressFrom, $addressTo){
    // Google API key
    $dotww_gmaps_key = get_option('dotww_gmaps_key') ? get_option('dotww_gmaps_key'):'';
    if($dotww_gmaps_key == ''){
        return 'Google Maps API Key not found!';
    }
    $apiKey = $dotww_gmaps_key;
    
    $api = file_get_contents("https://maps.googleapis.com/maps/api/distancematrix/json?origins=".urlencode($addressFrom)."&destinations=".urlencode($addressTo)."&key=".$apiKey."");
    $data = json_decode($api, true);
    if('OK' == $data['status']){
        $distance = explode(" ",$data['rows'][0]['elements'][0]['distance']['text'])[0];
        //echo 'distance: '.$distance;
        return $distance;
    }else{
        return $data['status'];
        
    }
}



add_action( 'wp_enqueue_scripts', 'hey_load_dot_script_front_js' );
function hey_load_dot_script_front_js(){
    wp_enqueue_script( 'hey-dot-front-js', plugins_url( 'js/dot_script_front.js', __FILE__ ), array('jquery'), '1.0.0', true );
    
    wp_register_style( 'hey-dot-front-css', plugins_url( 'css/dot_front.css', __FILE__) );
    wp_enqueue_style( 'hey-dot-front-css' );
}


add_action( 'woocommerce_after_checkout_validation', 'dot_validate_distance', 10, 2);
 
function dot_validate_distance( $fields, $errors ){

    $dotww_price_label = get_option('dotww_price_label') ? get_option('dotww_price_label'):'Additional Cost';
    $dotww_options = get_option('dotww_options');
    if($dotww_options){
        $dotww_options = json_decode($dotww_options, true);
    }else{
        $dotww_options = array();
    }
    
    foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
    	$quantity     = $cart_item['quantity']; 
    	$product_id   = $cart_item['product_id'];
    	$variation_id = $cart_item['variation_id'];

        $warehouses = wp_get_post_terms( $product_id, 'warehouse', array('fields' => 'names') );
        if ( count($warehouses) > 0 ) {
            $warehouses = $warehouses[0];
        }
	}


	//getting warehouse address of product
    $warehouse = get_term_by( 'slug', $warehouses, 'warehouse' );
    $warehouse_address = get_term_meta( $warehouse->term_id, 'dotww-address', true);
    
    
    //getting customer address
    global $woocommerce;
    
    $c_addr1 = $fields['billing_address_1'];
    $c_addr2 = $fields['billing_address_2'];
    $c_postcode = $fields['billing_postcode'];
    $c_city = $fields['billing_city'];
    $c_country = $fields['billing_country'];
    
    $destination_address=$c_addr1." ".$c_addr2." ".$c_postcode." ".$c_city." ".$c_country;
    
    if(!empty($dotww_options)){
        $distance = dot_get_distance ($warehouse_address, $destination_address);
        if(!is_numeric($distance)){
             //wc_add_notice( __( $distance, 'woocommerce' ), 'error' );
             return;
        }
        $price_to_be_added = 0;
        $dds = array_column($dotww_options, 'dotww_price');
        array_multisort($dds, SORT_DESC, $dotww_options);
        
        //$dotww_options = array_reverse($dotww_options);
        foreach($dotww_options as $condition){
            if($distance <= $condition['dotww_distance']){
                $price_to_be_added = $condition['dotww_price'];   
            }
        }
        $cartTotal=WC()->cart->get_cart_contents_total();
        if($price_to_be_added <= 0){
            // Notice
            $dotww_outofzone = get_option('dotww_outofzone_error') ? get_option('dotww_outofzone_error'):'Out of Zone. We cannot deliver this product to the selected city.';
            $errors->add( 'validation', $dotww_outofzone );
        }
    }

}
